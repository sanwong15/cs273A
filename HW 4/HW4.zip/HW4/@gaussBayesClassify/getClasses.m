function c=getClasses(obj)
% getClasses(obj) : return the list of class IDs associated with this classifier

c = obj.classes;
