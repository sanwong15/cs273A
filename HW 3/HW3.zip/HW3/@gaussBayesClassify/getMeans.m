function m = getMeans(obj)
% m = getMeans(gbc) : access the means of the classifier

m = obj.means;

