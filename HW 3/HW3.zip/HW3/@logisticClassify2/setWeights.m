function obj = setWeights(obj,wts)
% obj = setWeights(obj,wts) : set the 1 x (n+1) weights of the linear classifier

obj.wts = wts;
